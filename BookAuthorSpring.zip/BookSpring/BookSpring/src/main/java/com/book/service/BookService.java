package com.book.service;

import java.util.List;

import com.book.entities.Book;

public interface BookService {
	
	List<Book> getAll();
	
	void addBook(Book book);
	
	void deleteBook(int ISBNno);

}
