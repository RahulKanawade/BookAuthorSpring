package com.book.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.book.entities.Book;
import com.book.repository.BookRepository;

@Service
public class BookServiceImpl implements BookService{
	
	@Autowired
	BookRepository bookRepository;

	@Override
	public List<Book> getAll() {
		// TODO Auto-generated method stub
		List<Book> list = bookRepository.findAll();
		return list;
	}

	@Override
	public void addBook(Book book) {
		// TODO Auto-generated method stub
		bookRepository.save(book);
		
	}

	@Override
	public void deleteBook(int ISBNno) {
		// TODO Auto-generated method stub
		bookRepository.deleteById(ISBNno);
		
	}

}
