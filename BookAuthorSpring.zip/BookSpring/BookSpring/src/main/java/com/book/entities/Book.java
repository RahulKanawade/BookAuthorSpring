package com.book.entities;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
@Entity
@Table(name = "jpa_book")
public class Book {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int ISBNno;	
	private String tittle;	
	private String availability;
	@ManyToMany(cascade = CascadeType.ALL)
	private List<Author> author;
	public int getISBNno() {
		return ISBNno;
	}
	public void setISBNno(int iSBNno) {
		ISBNno = iSBNno;
	}
	public String getTittle() {
		return tittle;
	}
	public void setTittle(String tittle) {
		this.tittle = tittle;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	public List<Author> getAuthor() {
		return author;
	}
	public void setAuthor(List<Author> author) {
		this.author = author;
	}
	@Override
	public String toString() {
		return "Book [ISBNno=" + ISBNno + ", tittle=" + tittle + ", availability=" + availability + ", author=" + author
				+ "]";
	}
	public Book(int iSBNno, String tittle, String availability, List<Author> author) {
		super();
		ISBNno = iSBNno;
		this.tittle = tittle;
		this.availability = availability;
		this.author = author;
	}
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
